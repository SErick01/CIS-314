# SortOrganize

## Description
This program is designed to sort documents of various types by type and then rename them in structure format.

## Installation
To install SortOrganize, use pip:

```bash
pip install SortOrganize
